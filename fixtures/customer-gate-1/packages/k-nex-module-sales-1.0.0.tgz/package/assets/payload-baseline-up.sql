CREATE TYPE "public"."enum_sales_tasks_status" AS ENUM('open', 'done');
CREATE TYPE "public"."enum_sales_opportunities_stage" AS ENUM('lead', 'qualified', 'won', 'lost');
CREATE TABLE "sales_tasks" (
  "id" serial PRIMARY KEY NOT NULL, "title" varchar NOT NULL,
  "status" "enum_sales_tasks_status" DEFAULT 'open' NOT NULL, "potential_revenue" varchar, "private_note" varchar,
  "updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL, "created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
);
CREATE TABLE "sales_opportunities" (
  "id" serial PRIMARY KEY NOT NULL, "name" varchar NOT NULL,
  "stage" "enum_sales_opportunities_stage" DEFAULT 'lead' NOT NULL, "value" varchar,
  "updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL, "created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
);
CREATE TABLE "payload_kv" ("id" serial PRIMARY KEY NOT NULL, "key" varchar NOT NULL, "data" jsonb NOT NULL);
CREATE TABLE "users_sessions" (
  "_order" integer NOT NULL, "_parent_id" integer NOT NULL, "id" varchar PRIMARY KEY NOT NULL,
  "created_at" timestamp(3) with time zone, "expires_at" timestamp(3) with time zone NOT NULL
);
CREATE TABLE "users" (
  "id" serial PRIMARY KEY NOT NULL, "updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  "created_at" timestamp(3) with time zone DEFAULT now() NOT NULL, "email" varchar NOT NULL,
  "reset_password_token" varchar, "reset_password_expiration" timestamp(3) with time zone,
  "salt" varchar, "hash" varchar, "login_attempts" numeric DEFAULT 0, "lock_until" timestamp(3) with time zone
);
CREATE TABLE "payload_locked_documents" (
  "id" serial PRIMARY KEY NOT NULL, "global_slug" varchar,
  "updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL, "created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
);
CREATE TABLE "payload_locked_documents_rels" (
  "id" serial PRIMARY KEY NOT NULL, "order" integer, "parent_id" integer NOT NULL, "path" varchar NOT NULL,
  "sales_tasks_id" integer, "sales_opportunities_id" integer, "users_id" integer
);
CREATE TABLE "payload_preferences" (
  "id" serial PRIMARY KEY NOT NULL, "key" varchar, "value" jsonb,
  "updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL, "created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
);
CREATE TABLE "payload_preferences_rels" (
  "id" serial PRIMARY KEY NOT NULL, "order" integer, "parent_id" integer NOT NULL, "path" varchar NOT NULL, "users_id" integer
);
CREATE TABLE "payload_migrations" (
  "id" serial PRIMARY KEY NOT NULL, "name" varchar, "batch" numeric,
  "updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL, "created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
);
CREATE TABLE "k_nex_default_pages" (
  "template_id" varchar PRIMARY KEY NOT NULL, "ownership" varchar NOT NULL, "revision" integer DEFAULT 1 NOT NULL
);
INSERT INTO "k_nex_default_pages" ("template_id", "ownership") VALUES
  ('sales.page.tasks', 'customer'), ('sales.page.opportunities', 'customer');
ALTER TABLE "users_sessions" ADD CONSTRAINT "users_sessions_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."payload_locked_documents"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_sales_tasks_fk" FOREIGN KEY ("sales_tasks_id") REFERENCES "public"."sales_tasks"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_sales_opportunities_fk" FOREIGN KEY ("sales_opportunities_id") REFERENCES "public"."sales_opportunities"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_users_fk" FOREIGN KEY ("users_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "payload_preferences_rels" ADD CONSTRAINT "payload_preferences_rels_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."payload_preferences"("id") ON DELETE cascade ON UPDATE no action;
ALTER TABLE "payload_preferences_rels" ADD CONSTRAINT "payload_preferences_rels_users_fk" FOREIGN KEY ("users_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
CREATE INDEX "sales_tasks_updated_at_idx" ON "sales_tasks" USING btree ("updated_at");
CREATE INDEX "sales_tasks_created_at_idx" ON "sales_tasks" USING btree ("created_at");
CREATE INDEX "status_idx" ON "sales_tasks" USING btree ("status");
CREATE INDEX "sales_opportunities_updated_at_idx" ON "sales_opportunities" USING btree ("updated_at");
CREATE INDEX "sales_opportunities_created_at_idx" ON "sales_opportunities" USING btree ("created_at");
CREATE INDEX "stage_idx" ON "sales_opportunities" USING btree ("stage");
CREATE UNIQUE INDEX "payload_kv_key_idx" ON "payload_kv" USING btree ("key");
CREATE INDEX "users_sessions_order_idx" ON "users_sessions" USING btree ("_order");
CREATE INDEX "users_sessions_parent_id_idx" ON "users_sessions" USING btree ("_parent_id");
CREATE INDEX "users_updated_at_idx" ON "users" USING btree ("updated_at");
CREATE INDEX "users_created_at_idx" ON "users" USING btree ("created_at");
CREATE UNIQUE INDEX "users_email_idx" ON "users" USING btree ("email");
CREATE INDEX "payload_locked_documents_global_slug_idx" ON "payload_locked_documents" USING btree ("global_slug");
CREATE INDEX "payload_locked_documents_updated_at_idx" ON "payload_locked_documents" USING btree ("updated_at");
CREATE INDEX "payload_locked_documents_created_at_idx" ON "payload_locked_documents" USING btree ("created_at");
CREATE INDEX "payload_locked_documents_rels_order_idx" ON "payload_locked_documents_rels" USING btree ("order");
CREATE INDEX "payload_locked_documents_rels_parent_idx" ON "payload_locked_documents_rels" USING btree ("parent_id");
CREATE INDEX "payload_locked_documents_rels_path_idx" ON "payload_locked_documents_rels" USING btree ("path");
CREATE INDEX "payload_locked_documents_rels_sales_tasks_id_idx" ON "payload_locked_documents_rels" USING btree ("sales_tasks_id");
CREATE INDEX "payload_locked_documents_rels_sales_opportunities_id_idx" ON "payload_locked_documents_rels" USING btree ("sales_opportunities_id");
CREATE INDEX "payload_locked_documents_rels_users_id_idx" ON "payload_locked_documents_rels" USING btree ("users_id");
CREATE INDEX "payload_preferences_key_idx" ON "payload_preferences" USING btree ("key");
CREATE INDEX "payload_preferences_updated_at_idx" ON "payload_preferences" USING btree ("updated_at");
CREATE INDEX "payload_preferences_created_at_idx" ON "payload_preferences" USING btree ("created_at");
CREATE INDEX "payload_preferences_rels_order_idx" ON "payload_preferences_rels" USING btree ("order");
CREATE INDEX "payload_preferences_rels_parent_idx" ON "payload_preferences_rels" USING btree ("parent_id");
CREATE INDEX "payload_preferences_rels_path_idx" ON "payload_preferences_rels" USING btree ("path");
CREATE INDEX "payload_preferences_rels_users_id_idx" ON "payload_preferences_rels" USING btree ("users_id");
CREATE INDEX "payload_migrations_updated_at_idx" ON "payload_migrations" USING btree ("updated_at");
CREATE INDEX "payload_migrations_created_at_idx" ON "payload_migrations" USING btree ("created_at");
